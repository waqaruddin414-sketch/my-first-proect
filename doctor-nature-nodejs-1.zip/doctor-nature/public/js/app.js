// ═══════════════════════════════════════════════════════
//  ڈاکٹر نیچر — Frontend JS
// ═══════════════════════════════════════════════════════

const chatWindow  = document.getElementById("chatWindow");
const msgInput    = document.getElementById("msgInput");
const sendBtn     = document.getElementById("sendBtn");
const attachBtn   = document.getElementById("attachBtn");
const fileInput   = document.getElementById("fileInput");
const filePreview = document.getElementById("filePreview");
const resetBtn    = document.getElementById("resetBtn");
const quickBtns   = document.getElementById("quickBtns");

let history     = [];   // { role, content } array sent to server
let attachments = [];   // { name, file } pending files

const WELCOME = `بِسْمِ اللّٰہِ الرَّحْمٰنِ الرَّحِیْم\n\nالسلام علیکم!\nمیں ڈاکٹر نیچر ہوں — قدرتی صحت کا آپ کا ہمسفر۔\n\nاللہ تعالیٰ نے ہر بیماری کا علاج قدرت میں رکھا ہے:\n🌿 غذاؤں کی تاثیر سے علاج\n🌱 جڑی بوٹیوں کے قدرتی نسخے\n🌅 لائف سٹائل میں تبدیلی\n📋 لیب رپورٹ کا تجزیہ اور قدرتی حل\n🤲 نبوی صلی اللہ علیہ وسلم کے صحت کے اصول\n\nمیرا مقصد: آپ کو ڈاکٹر، دوا، اور بیماری سے بچانا\n\n📎 لیب رپورٹ بھیجیں (تصویر یا PDF) یا علامات بتائیں\n\n⚠️ نوٹ: یہ قدرتی رہنمائی ہے — سنگین بیماری میں ڈاکٹر سے ضرور ملیں`;

// ─── Init ────────────────────────────────────────────────
window.addEventListener("DOMContentLoaded", () => {
  appendBotMsg(WELCOME);
});

// ─── Reset ───────────────────────────────────────────────
resetBtn.addEventListener("click", () => {
  history = [];
  attachments = [];
  chatWindow.innerHTML = "";
  filePreview.innerHTML = "";
  quickBtns.style.display = "flex";
  msgInput.value = "";
  appendBotMsg(WELCOME);
});

// ─── Quick Suggestions ───────────────────────────────────
quickBtns.querySelectorAll(".quick-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    msgInput.value = btn.dataset.q;
    msgInput.focus();
    quickBtns.style.display = "none";
  });
});

// ─── File Attach ─────────────────────────────────────────
attachBtn.addEventListener("click", () => fileInput.click());

fileInput.addEventListener("change", () => {
  Array.from(fileInput.files).forEach(f => {
    attachments.push({ name: f.name, file: f });
  });
  fileInput.value = "";
  renderFilePreview();
});

function renderFilePreview() {
  filePreview.innerHTML = "";
  attachments.forEach((a, i) => {
    const chip = document.createElement("div");
    chip.className = "file-chip";
    const icon = a.file.type.startsWith("image") ? "🖼️" : "📄";
    chip.innerHTML = `
      <span>${icon}</span>
      <span class="file-name">${a.name}</span>
      <button onclick="removeFile(${i})">✕</button>`;
    filePreview.appendChild(chip);
  });
}
window.removeFile = (i) => {
  attachments.splice(i, 1);
  renderFilePreview();
};

// ─── Keyboard send ───────────────────────────────────────
msgInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});
sendBtn.addEventListener("click", sendMessage);

// ─── Send ─────────────────────────────────────────────────
async function sendMessage() {
  const text = msgInput.value.trim();
  if (!text && attachments.length === 0) return;
  if (sendBtn.disabled) return;

  // hide quick btns after first message
  quickBtns.style.display = "none";

  // display label
  const label = attachments.map(a => `📎 ${a.name}`).join("  ")
    + (text ? (attachments.length ? "\n" : "") + text : "");
  appendUserMsg(label);

  msgInput.value = "";
  const pendingFiles = [...attachments];
  attachments = [];
  filePreview.innerHTML = "";
  setSending(true);

  // build FormData
  const fd = new FormData();
  fd.append("message", text);
  fd.append("history", JSON.stringify(history));
  pendingFiles.forEach(a => fd.append("files", a.file));

  // optimistic history entry (text only for history)
  const historyText = text || "یہ لیب رپورٹ پڑھیں اور قدرتی علاج کا مکمل پلان دیں۔";
  history.push({ role: "user", content: historyText });

  showTyping();

  try {
    const res  = await fetch("/api/chat", { method: "POST", body: fd });
    const data = await res.json();
    removeTyping();

    if (!res.ok) throw new Error(data.error || "Server error");

    const reply = data.reply;
    history.push({ role: "assistant", content: reply });
    appendBotMsg(reply);
  } catch (err) {
    removeTyping();
    history.pop(); // revert
    appendBotMsg("⚠️ کنکشن میں مسئلہ ہے: " + err.message);
  } finally {
    setSending(false);
  }
}

function setSending(on) {
  sendBtn.disabled = on;
  sendBtn.textContent = on ? "⏳" : "🌿";
}

// ─── Typing Indicator ─────────────────────────────────────
function showTyping() {
  const row = document.createElement("div");
  row.className = "typing-row"; row.id = "typingRow";
  row.innerHTML = `
    <div class="avatar bot">🌿</div>
    <div class="typing-bubble">
      <div class="dot-anim"></div>
      <div class="dot-anim"></div>
      <div class="dot-anim"></div>
    </div>`;
  chatWindow.appendChild(row);
  scrollBottom();
}
function removeTyping() {
  const row = document.getElementById("typingRow");
  if (row) row.remove();
}

// ─── Append Messages ──────────────────────────────────────
function appendUserMsg(text) {
  const row  = document.createElement("div");
  row.className = "msg-row user";
  const bubble = document.createElement("div");
  bubble.className = "bubble user";
  bubble.innerHTML = textToHtml(text);
  const avatar = document.createElement("div");
  avatar.className = "avatar user"; avatar.textContent = "👤";

  const body = document.createElement("div");
  body.className = "msg-body";
  body.appendChild(bubble);

  row.appendChild(body);
  row.appendChild(avatar);
  chatWindow.appendChild(row);
  scrollBottom();
}

function appendBotMsg(raw) {
  const row  = document.createElement("div");
  row.className = "msg-row bot";

  const avatar = document.createElement("div");
  avatar.className = "avatar bot"; avatar.textContent = "🌿";

  const body = document.createElement("div");
  body.className = "msg-body";

  // main bubble (cleaned text)
  const bubble = document.createElement("div");
  bubble.className = "bubble bot";
  bubble.innerHTML = textToHtml(cleanContent(raw));
  body.appendChild(bubble);

  // structured cards
  const reportCard    = buildReportCard(raw);
  const foodCard      = buildFoodCard(raw);
  const herbCard      = buildHerbCard(raw);
  const lifestyleCard = buildLifestyleCard(raw);
  if (reportCard)    body.appendChild(reportCard);
  if (foodCard)      body.appendChild(foodCard);
  if (herbCard)      body.appendChild(herbCard);
  if (lifestyleCard) body.appendChild(lifestyleCard);

  row.appendChild(avatar);
  row.appendChild(body);
  chatWindow.appendChild(row);
  scrollBottom();
}

function scrollBottom() {
  setTimeout(() => chatWindow.scrollTop = chatWindow.scrollHeight, 60);
}

// ─── Text → HTML ──────────────────────────────────────────
function textToHtml(text) {
  return text.split("\n").map(line => {
    const t = line.trim();
    if (!t) return "<br>";
    if (t.startsWith("بِسْمِ"))         return `<p class="bism">${esc(t)}</p>`;
    if (t.startsWith("**") && t.endsWith("**")) return `<p class="head">${esc(t.slice(2,-2))}</p>`;
    if (/^[🌿🥗🌱🌅💧🤲📋]/.test(t)) return `<p class="head">${esc(t)}</p>`;
    if (t.startsWith("⚠️"))             return `<p class="warn">${esc(t)}</p>`;
    if (t.startsWith("✅"))             return `<p class="yes">${esc(t)}</p>`;
    if (t.startsWith("❌"))             return `<p class="no">${esc(t)}</p>`;
    return `<p>${esc(t)}</p>`;
  }).join("");
}
function esc(s) {
  return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

// ─── Clean delimiters ─────────────────────────────────────
function cleanContent(c) {
  return c
    .replace(/REPORT_START[\s\S]*?REPORT_END/g,"")
    .replace(/FOODS_START[\s\S]*?FOODS_END/g,"")
    .replace(/HERBS_START[\s\S]*?HERBS_END/g,"")
    .replace(/LIFESTYLE_START[\s\S]*?LIFESTYLE_END/g,"");
}

// ─── Card builders ────────────────────────────────────────

/* --- Report Card --- */
function buildReportCard(raw) {
  const block = extractBlock(raw, "REPORT_START", "REPORT_END");
  if (!block) return null;
  const params = [];
  block.split("\n").forEach(line => {
    const t = line.trim();
    if (!t.startsWith("PARAM:")) return;
    const p = t.split("|");
    params.push({
      name:    p[0]?.replace("PARAM:","").trim() || "",
      value:   p[1]?.replace("VALUE:","").trim() || "",
      status:  p[2]?.replace("STATUS:","").trim() || "نارمل",
      meaning: p[3]?.replace("MEANING:","").trim() || ""
    });
  });
  if (!params.length) return null;

  const card = makeCard("report");
  card.innerHTML = `<div class="card-title"><span>رپورٹ کا تجزیہ</span><span>📋</span></div>`;
  params.forEach(p => {
    const cls   = p.status==="زیادہ" ? "high" : p.status==="کم" ? "low" : "normal";
    const icon  = p.status==="زیادہ" ? "⬆️" : p.status==="کم" ? "⬇️" : "✅";
    const row   = document.createElement("div");
    row.className = "card-row";
    row.innerHTML = `
      <div class="card-row-head">
        <span class="tag ${cls}">${icon} ${esc(p.status)}</span>
        <span class="card-name">${esc(p.name)}${p.value?" — <small style='color:#94a3b8'>"+esc(p.value)+"</small>":""}</span>
      </div>
      ${p.meaning ? `<div class="card-sub">${esc(p.meaning)}</div>` : ""}`;
    card.appendChild(row);
  });
  return card;
}

/* --- Food Card --- */
function buildFoodCard(raw) {
  const block = extractBlock(raw, "FOODS_START", "FOODS_END");
  if (!block) return null;
  const items = [];
  block.split("\n").forEach(line => {
    const t = line.trim();
    if (!t.startsWith("FOOD:")) return;
    const p = t.split("|");
    items.push({
      name:    p[0]?.replace("FOOD:","").trim() || "",
      effect:  p[1]?.replace("EFFECT:","").trim() || "",
      benefit: p[2]?.replace("BENEFIT:","").trim() || "",
      how:     p[3]?.replace("HOW:","").trim() || ""
    });
  });
  if (!items.length) return null;

  const card = makeCard("foods");
  card.innerHTML = `<div class="card-title"><span>غذائی علاج</span><span>🥗</span></div>`;
  items.forEach(f => {
    const cls = f.effect?.includes("گرم") ? "warm" : f.effect?.includes("سرد") ? "cold" : "neutral";
    const row = document.createElement("div");
    row.className = "card-row";
    row.innerHTML = `
      <div class="card-row-head">
        <span class="tag ${cls}">${esc(f.effect||"معتدل")}</span>
        <span class="card-name">🌿 ${esc(f.name)}</span>
      </div>
      ${f.benefit ? `<div class="card-sub" style="color:#86efac">${esc(f.benefit)}</div>` : ""}
      ${f.how     ? `<div class="card-sub">👉 ${esc(f.how)}</div>` : ""}`;
    card.appendChild(row);
  });
  return card;
}

/* --- Herb Card --- */
function buildHerbCard(raw) {
  const block = extractBlock(raw, "HERBS_START", "HERBS_END");
  if (!block) return null;
  const items = [];
  block.split("\n").forEach(line => {
    const t = line.trim();
    if (!t.startsWith("HERB:")) return;
    const p = t.split("|");
    items.push({
      name:    p[0]?.replace("HERB:","").trim() || "",
      dose:    p[1]?.replace("DOSE:","").trim() || "",
      benefit: p[2]?.replace("BENEFIT:","").trim() || "",
      time:    p[3]?.replace("TIME:","").trim() || ""
    });
  });
  if (!items.length) return null;

  const card = makeCard("herbs");
  card.innerHTML = `<div class="card-title"><span>جڑی بوٹیاں / قدرتی نسخے</span><span>🌱</span></div>`;
  items.forEach(h => {
    const row = document.createElement("div");
    row.className = "card-row";
    row.innerHTML = `
      <div class="card-row-head">
        ${h.time ? `<span class="tag time">${esc(h.time)}</span>` : ""}
        <span class="card-name">🌿 ${esc(h.name)}</span>
      </div>
      ${h.dose    ? `<div class="card-sub" style="color:#a3e635">مقدار: ${esc(h.dose)}</div>` : ""}
      ${h.benefit ? `<div class="card-sub">${esc(h.benefit)}</div>` : ""}`;
    card.appendChild(row);
  });
  return card;
}

/* --- Lifestyle Card --- */
function buildLifestyleCard(raw) {
  const block = extractBlock(raw, "LIFESTYLE_START", "LIFESTYLE_END");
  if (!block) return null;
  const items = [];
  block.split("\n").forEach(line => {
    const t = line.trim();
    if (!t.startsWith("HABIT:")) return;
    const p = t.split("|");
    items.push({
      name:   p[0]?.replace("HABIT:","").trim() || "",
      type:   p[1]?.replace("TYPE:","").trim() || "",
      reason: p[2]?.replace("REASON:","").trim() || ""
    });
  });
  if (!items.length) return null;

  const card = makeCard("lifestyle");
  card.innerHTML = `<div class="card-title"><span>لائف سٹائل تبدیلیاں</span><span>🌅</span></div>`;
  items.forEach(h => {
    const drop = h.type?.includes("ترک") || h.type?.includes("چھوڑ");
    const cls  = drop ? "drop" : "add";
    const icon = drop ? "❌" : "✅";
    const row  = document.createElement("div");
    row.className = "card-row";
    row.innerHTML = `
      <div class="card-row-head">
        <span class="tag ${cls}">${icon} ${esc(h.type)}</span>
        <span class="card-name">${esc(h.name)}</span>
      </div>
      ${h.reason ? `<div class="card-sub">${esc(h.reason)}</div>` : ""}`;
    card.appendChild(row);
  });
  return card;
}

// ─── Helpers ──────────────────────────────────────────────
function makeCard(type) {
  const d = document.createElement("div");
  d.className = `card ${type}`;
  return d;
}
function extractBlock(raw, startTag, endTag) {
  const s = raw.indexOf(startTag);
  const e = raw.indexOf(endTag);
  if (s === -1 || e === -1) return null;
  return raw.substring(s + startTag.length, e);
}
