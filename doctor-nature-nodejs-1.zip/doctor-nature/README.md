# 🌿 ڈاکٹر نیچر — Node.js

نیچروپیتھی AI معاون — قدرتی غذا، جڑی بوٹیاں، لائف سٹائل، اور لیب رپورٹ تجزیہ

---

## 📁 فولڈر ڈھانچہ

```
doctor-nature/
├── server.js          ← Node.js سرور (Express)
├── package.json
├── .env               ← API Key یہاں لکھیں
├── .env.example       ← نمونہ
└── public/
    ├── index.html     ← مرکزی صفحہ
    ├── css/
    │   └── style.css
    └── js/
        └── app.js
```

---

## ⚙️ انسٹالیشن

### 1. Node.js انسٹال کریں
https://nodejs.org سے LTS ورژن ڈاؤن لوڈ کریں

### 2. پروجیکٹ فولڈر میں جائیں
```bash
cd doctor-nature
```

### 3. packages انسٹال کریں
```bash
npm install
```

### 4. API Key سیٹ کریں
```bash
# .env.example کو copy کریں
copy .env.example .env        # Windows
cp .env.example .env          # Mac/Linux

# .env فائل کھولیں اور لکھیں:
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx
```

### 5. سرور چلائیں
```bash
npm start
```

### 6. براؤزر میں کھولیں
```
http://localhost:3000
```

---

## 🌟 خصوصیات

- 🥗 **غذائی علاج** — تاثیر (گرم/سرد) کے ساتھ
- 🌱 **جڑی بوٹیاں** — مقدار اور وقت کے ساتھ
- 🌅 **لائف سٹائل** — کیا شامل کریں، کیا ترک کریں
- 📋 **لیب رپورٹ** — تصویر یا PDF اپلوڈ کریں
- 🤲 **اسلامی نقطہ نظر** — نبوی غذائیں اور قرآنی پھل
- 📱 **موبائل فرینڈلی** — ہر اسکرین پر بہترین

---

## 🔑 Anthropic API Key کہاں سے ملے؟

https://console.anthropic.com پر جا کر مفت account بنائیں
اور API Keys سیکشن سے key لیں۔

---

**Waqaruddin Projects — ملتان، پاکستان**
