require("dotenv").config();
const express  = require("express");
const multer   = require("multer");
const path     = require("path");
const fs       = require("fs");
const Anthropic = require("@anthropic-ai/sdk");

const app  = express();
const port = process.env.PORT || 3000;
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ─── Multer (فائل اپلوڈ) ───────────────────────────────────
const storage = multer.memoryStorage();          // میموری میں رکھیں، ڈسک پر نہیں
const upload  = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 },       // 20 MB
  fileFilter: (req, file, cb) => {
    const allowed = ["image/jpeg","image/png","image/webp","image/gif","application/pdf"];
    cb(null, allowed.includes(file.mimetype));
  }
});

// ─── Middleware ────────────────────────────────────────────
app.use(express.json({ limit: "5mb" }));
app.use(express.static(path.join(__dirname, "public")));

// ─── System Prompt ─────────────────────────────────────────
const SYSTEM_PROMPT = `آپ "ڈاکٹر نیچر" ہیں — ایک ماہر نیچروپیتھی معاون جو قدرتی غذاؤں، جڑی بوٹیوں، اور لائف سٹائل تبدیلیوں کے ذریعے انسانی صحت بہتر بنانے میں مدد کرتا ہے۔

آپ کا مشن: انسانوں کو ڈاکٹر، دوا، اور بیماری سے بچانا — قدرت کے خزانوں کے ذریعے۔

**آپ کا انداز:**
- خالص اردو میں بات کریں، محبت، علم، اور اسلامی روح کے ساتھ
- ہر غذا کی "تاثیر" (گرم/سرد/خشک/تر) بتائیں
- قرآن و حدیث کی روشنی میں قدرتی علاج کا حوالہ دیں جہاں مناسب ہو
- ایک وقت میں ایک سوال پوچھیں

**لیب رپورٹ تجزیہ (جب رپورٹ فراہم کی جائے):**
اگر صارف لیب رپورٹ بھیجے تو:
1. تمام اہم ٹیسٹ پڑھیں اور غیر معمولی قدریں نوٹ کریں
2. ہر غیر معمولی قدر کے لیے وضاحت دیں
3. مکمل نیچروپیتھی پلان دیں

رپورٹ تجزیہ فارمیٹ:
📋 **رپورٹ کا خلاصہ:**
REPORT_START
PARAM: [ٹیسٹ کا نام] | VALUE: [قدر] | STATUS: [نارمل/زیادہ/کم] | MEANING: [کیا مطلب ہے]
REPORT_END

**تشخیص کا طریقہ (علامات کے لیے):**
1. پہلے علامات یا صحت کا مسئلہ پوچھیں
2. عمر، جنس، موسم / ماحول پوچھیں
3. موجودہ خوراک کا مختصر جائزہ لیں
4. روزمرہ کی عادات پوچھیں
5. کم از کم 4 سوالوں کے بعد مکمل نیچروپیتھی پلان دیں

**جواب کا فارمیٹ:**

🌿 **قدرتی تشخیص:**
(مسئلے کی وجہ)

🥗 **غذائی علاج:**
FOODS_START
FOOD: [غذا] | EFFECT: [گرم/سرد] | BENEFIT: [فائدہ] | HOW: [طریقہ]
FOODS_END

🌱 **جڑی بوٹیاں:**
HERBS_START
HERB: [نام] | DOSE: [مقدار] | BENEFIT: [فائدہ] | TIME: [وقت]
HERBS_END

🌅 **لائف سٹائل:**
LIFESTYLE_START
HABIT: [عادت] | TYPE: [شامل کریں/ترک کریں] | REASON: [وجہ]
LIFESTYLE_END

💧 **پانی اور نیند کی ہدایات:**

🤲 **اسلامی نقطہ نظر:**

⚠️ **یاد دہانی:** یہ قدرتی رہنمائی ہے۔ سنگین بیماری میں معالج سے رجوع کریں۔

**مہارت:** شہد، کلونجی، زیتون، سرکہ، ادرک، ہلدی، دارچینی، لہسن، کھجور، انجیر، انار — نبوی اور قرآنی غذائیں۔ CBC, LFT, KFT, Lipid Profile, HbA1c, Thyroid, Vitamin D/B12 رپورٹ تجزیہ۔`;

// ─── Chat API Route ─────────────────────────────────────────
app.post("/api/chat", upload.array("files", 5), async (req, res) => {
  try {
    let history = [];
    try { history = JSON.parse(req.body.history || "[]"); } catch {}
    const userText = (req.body.message || "").trim();
    const files    = req.files || [];

    // آخری صارف پیغام بنائیں
    let lastContent;
    if (files.length === 0) {
      lastContent = userText || "یہ لیب رپورٹ پڑھیں اور قدرتی علاج کا مکمل پلان دیں۔";
    } else {
      lastContent = [];
      files.forEach(f => {
        const b64 = f.buffer.toString("base64");
        if (f.mimetype.startsWith("image/")) {
          lastContent.push({ type:"image", source:{ type:"base64", media_type:f.mimetype, data:b64 }});
        } else if (f.mimetype === "application/pdf") {
          lastContent.push({ type:"document", source:{ type:"base64", media_type:"application/pdf", data:b64 }});
        }
      });
      lastContent.push({ type:"text", text: userText || "یہ لیب رپورٹ پڑھیں اور قدرتی علاج کا مکمل پلان دیں۔" });
    }

    const messages = [...history, { role:"user", content:lastContent }];

    const response = await anthropic.messages.create({
      model:      "claude-sonnet-4-20250514",
      max_tokens: 2000,
      system:     SYSTEM_PROMPT,
      messages
    });

    const reply = response.content?.[0]?.text || "معذرت، جواب نہیں مل سکا۔";
    res.json({ reply });

  } catch (err) {
    console.error("API Error:", err.message);
    res.status(500).json({ error: "سرور میں مسئلہ ہے: " + err.message });
  }
});

// ─── Health check ───────────────────────────────────────────
app.get("/health", (req, res) => res.json({ status:"ok", app:"ڈاکٹر نیچر v2.0" }));

// ─── Start ─────────────────────────────────────────────────
app.listen(port, () => {
  console.log(`\n🌿 ڈاکٹر نیچر چل رہا ہے`);
  console.log(`🌐 http://localhost:${port}\n`);
});
